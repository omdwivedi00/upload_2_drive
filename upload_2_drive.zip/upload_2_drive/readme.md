
 This script allows you to upload video files to Google Drive. Follow the steps below to run the script and provide necessary inputs.

## Prerequisites

- Python installed on your system.
- Google Drive API credentials (client secret file).
-  `Google.py` module.

## Steps:

1. **Clone the Repository:**

   Clone the repository containing the script to your local machine.

   ```bash
   git clone <repository-url>

2.  **Navigate to the Directory:**
    
    Navigate to the directory where the script is located.
    

     ```bash
    cd path/to/repository
  
3.  **Install Required Libraries:**
    
    Install the required libraries by running the following command:
    
    ```bash
    pip install google-api-python-client tqdm
    
4.  **Obtain Google Client Secret:**
    
    Obtain the Google client secret file (**client_secret.json**`) by following these steps:
    
    -   Go to the Google API Console: https://console.developers.google.com/
    -   Create a new project or select an existing one.
    -   Navigate to the "Credentials" tab.
    -   Click on "Create credentials" and select "OAuth client ID".
    -   Choose "Desktop app" as the application type and give it a name.
    -   Download the client secret file (`client_secret.json`).


       **warning** , must replace 
       `CLIENT_SECRET_FILE = 'client_secret_398033380221-b2rblk2tbko9h2aovrcvl3t31mr2v7ai.apps.googleusercontent.com.json'`
        `CLIENT_SECRET_FILE = your_client_secret.json`

5.  **Run the Script:**
    
    Run the `update_to_drive.py` script using the following command:
    
    ```bash
    python update_to_drive.py 
6. **Google OAuth Consent Screen:**

    When you run the script for the first time, it may open a browser window automatically to initiate the OAuth authentication process with Google. If it doesn't open automatically, the script will provide a URL in the prompt. However, when accessing the OAuth consent screen, Google may display a warning message stating that the app is not verified. This is because the script is using OAuth for authentication, and Google requires apps to undergo a verification process to ensure they meet certain security and privacy standards.

    To proceed, click on the "Advanced" link (usually located at the bottom of the warning message), then click on the option to proceed to the script (your_app_name) despite it being "unsafe". For example, if the app name is "upload_to_drive", click on "upload_to_drive(unsafe)".

    
7.  **Follow the Prompts:**
    
    -   The script will prompt you to enter whether you want to use a different Google Drive account (y/n). If you choose 'y', the script will remove existing token files and proceed.
    -   Next, you will be prompted to enter the folder ID of the destination folder in Google Drive. You can obtain the folder ID from the URL of the folder shown in the browser's address bar. For example, if the URL to the folder is  
    -`https://drive.google.com/drive/folders/1Rdj4ZDg7Q-CY8wKKMxCay`, 
    then the ID should be `1Rdj4ZDg7Q-CY8wKKMxCay`.
    -   You will also need to provide the local folder path where the videos to be uploaded are located.
8.  **Provide Inputs:**
    
    -   If you want to start uploading from a specific point in the folder, enter the starting index when prompted.
    -   Once all inputs are provided, the script will start uploading the videos to the specified Google Drive folder.
9.  **Monitor Progress:**
    
    The script will display a progress bar indicating the upload progress for each video file.
    
10.  **Completion:**
    
    Once all videos are uploaded, the script will create a file named `last_uploaded_video.txt`, indicating the last uploaded video's number and path.
    
11.  **Finish:**
         You have successfully uploaded videos to Google Drive using the script.


from googleapiclient.http import MediaFileUpload
from Google import create_service  
from Google import remove_token_folder
import os 
from tqdm.auto import tqdm



while True:
        choice = input("Do you want to use a different google drive account? (y/n): ")
        if choice.lower() == 'y':
            remove_token_folder()
            break
        elif choice.lower() == 'n':
            break
        else:
            print("Invalid choice. Please enter y for 'yes' or n for  'no'.")





CLIENT_SECRET_FILE = 'client_secret_398033380221-b2rblk2tbko9h2aovrcvl3t31mr2v7ai.apps.googleusercontent.com.json'
API_NAME = 'drive'
API_VERSION = 'v3'
SCOPES = ['https://www.googleapis.com/auth/drive']

service = create_service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)

def write_number_to_file(number , name ):
    """
    Write a number to a file named 'last_downloaded_video.txt'.
    
    Args:
    - number: The number to be written to the file.
    
    Returns:
    - True if writing is successful, False otherwise.
    """
    try:
        # Open the file in write mode
        with open('last_uploaded_video.txt', 'w') as file:
            # Write the number to the file
            file.write(f'last uploaded video is video Number{str(number)} \n path= {name} restart from {str(number +1)}')
       
        return True
    except Exception as e:
        print(f"Error writing number to file: {e}")
        return False
    
def upload_to_drive(folder_id , filename ): 
        
        if filename.endswith('.mp4'):  # Adjust the extension if needed
            video_path = os.path.join(folder_path, filename)
            file_metadata = {
                'name': filename,
                'parents': [folder_id]
            }
            media_content = MediaFileUpload(video_path)

            # Upload the video file
            file = service.files().create(
                
                body=file_metadata,
                media_body=media_content
            ).execute()
            return True
        return False
        

def upload_videos_to_drive(folder_path, folder_id):
    """
    Upload all videos from a folder to Google Drive.
    
    Args:
    - folder_path: Path to the folder containing videos.
    - folder_id: ID of the Google Drive folder where videos will be uploaded.
    """
    start_from =0  
    start_point = input("enter  a starting point if  you want to start for bigning the type 0 >>")
    if int(start_point) !=0 : 
         start_from = int(start_point) 
    file_list =os.listdir(folder_path)
    print(file_list)
    file_list_length = len(file_list[start_from : ])
    
    progress_bar = tqdm(range(file_list_length))

    for index , filename in enumerate(file_list):
         if start_from <= index : 
            data = upload_to_drive(folder_id, filename) 
            if data : 
                write_number_to_file(number=index ,name =filename)
                progress_bar.update(1)
            else: 
                raise Exception(f'{filename} \n error in downloading in above url ') 
    
    progress_bar.close() 
         
    return True
    




while True:

    folder_id= input("Enter the  folder ID >>")
    folder_path = input("Enter folder path >>")
    if len(folder_id) !=0 and len(folder_path ) !=0: 
            
            upload_videos_to_drive(str(folder_path), folder_id)
            
            break
    else:
            print("Invalid choice. Please enter valid folder  and path ")





#1DDUuSzk5azfKIQ7ZD2BFgilpQZ10VOKf